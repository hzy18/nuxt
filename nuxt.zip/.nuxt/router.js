import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _0565bba1 = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _258f6716 = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _e6d477dc = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _d1484fdc = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _202c5cb9 = () => interopDefault(import('..\\pages\\setting' /* webpackChunkName: "" */))
const _0cd23c38 = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _7e261b5f = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _0565bba1,
    children: [{
      path: "",
      component: _258f6716,
      name: "home"
    }, {
      path: "/login",
      component: _e6d477dc,
      name: "login"
    }, {
      path: "/register",
      component: _e6d477dc,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _d1484fdc,
      name: "profile"
    }, {
      path: "/setting",
      component: _202c5cb9,
      name: "setting"
    }, {
      path: "/editor",
      component: _0cd23c38,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _7e261b5f,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
